 <?php


    session_start();
    unset($_SESSION['email']);  

    include_once('dbConn.php');
    include_once('createTable.php');
	
	
    $output = NULL;
    $email = $pass = "";

    if(isset($_POST['submit']))
    {
    
        $_SESSION['email'] = $_POST['email'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $hpass = md5($pass);

        $query = "SELECT email, password FROM tblcustomers WHERE email = '$email' AND password = '$hpass'";
        
        $result = mysqli_query($conn,$query);

        $row = mysqli_fetch_array($result);

        $x = $input['email'];
        $y = $input['password'];
        

        if(empty($email))
        {
            $output = "Please eneter email";
        }

        else 
        { 
             if($x == $email && $y == $hpass) 
             {
                 header("location:index.php");
             }
            else 
            {
                $output = "Incorrect Username\Password";
            }
        
        }
        
        
        
        
        
        if(empty($email))
        {
            $output = "Please eneter email";
        }
        elseif (mysqli_num_rows($result) != 1)
        {
            $output = "Incorrect Username / Password";
        }
        else 
        {
        header("location:index.php");
        }
       
    
    }
    ?>

	<!DOCTYPE html>
	<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<h1>Princess Purses Store<h1>
 <form method="post">
     	<h2>LOGIN</h2>
     	
     	
     	<label>User Name</label>
     	<input type="text" name="email" placeholder="email"><br>

     	<label>Password</label>
     	<input type="password" name="pass"  "<?php echo $email; ?>" placeholder="Password"><br>

     	<input type="submit" name="submit" value="Login"><br>
          <a href="register.php" class="ca">Create an account</a>
     </form>


	</html>
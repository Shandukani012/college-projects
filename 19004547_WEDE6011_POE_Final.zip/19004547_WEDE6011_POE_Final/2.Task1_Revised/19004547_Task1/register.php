<?php

    include('dbConn.php');
    $output = NULL;
    $fname = $lname = $email = $pass =  $rpass = "";

    if(isset($_POST['submit']))
    {
    
        $fname = $_POST['fname'];
		$lname = $_POST['lname'];
        $email = $_POST['email'];
        $pass = $_POST['pass']; 
        $rpass = $_POST['rpass'];
        
        $pattern = '/^(?=.*[!@#$%^&*-?])(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{4,20}$/';
		
        $query = "SELECT * FROM tblcustomers WHERE email = '$email'";
    
        $checkUserExsists = mysqli_query($conn,$query);
        
        if(empty($fname) || empty($lname) || empty($email) || empty($pass) || empty($rpass))
        {
            $output = "Fields cannot be empty";
        }
        elseif(filter_var($email, FILTER_VALIDATE_EMAIL) != true)
        {
            $output = "Invliad Email address";
        }
        elseif(mysqli_num_rows($checkUserExsists) == 1)
        {
            $output = "User already exsists";
        }

        elseif($pass != $rpass)
        {
            $output = "Passwords do not match";
        }

		elseif(!preg_match($pattern, $pass))
		{
			$output = "Password is not strong enough";
		}
        else
        {
			
            $pass = md5($pass);
            $query = "INSERT INTO tblcustomers (fname,lname, email, password) VALUES ('$fname','$lname','$email','$pass')";
            $insertUser = mysqli_query($conn,$query);
            if ($insertUser == true) 
            {
                $output = "You have Sucessfully been Registered";
            
			}
        }
    
    
    }
	
?>

<!DOCTYPE html>
<html>
<head>
	<title>SIGN UP</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    
    <form method="post">
     	<h2>SIGN UP</h2>
     
          <label>Name</label>
         
               <input type="text" 
                      name="fname" 
                      placeholder="Name"
                      value="<?php echo $fname; ?>"><br>
            <label>Last Name</label>
               <input type="text" 
                      name="lname" 
                      placeholder="Last Name"
					  "<?php echo $lname; ?>"><br>
       

          <label>UserName</label>
         
               <input type="text" 
                      name="email" 
                      placeholder="email"
                      value="<?php echo $email; ?>"><br>

     	<label>Password</label>
     	<input type="password" 
                 name="pass" 
                 placeholder="Password"><br>

          <label>Re Password</label>
          <input type="password" 
                 name="rpass" 
                 placeholder="password"><br>

     	<input type="submit" name="submit" value="Register">
      
     </form>
	 
	 
	 <?php
    echo "<br>";
    echo $output;
    ?>
        
        <p>Already have an Account : Click here to <a href="login.php">Login</a></p> 
       
    
</body>
</html>
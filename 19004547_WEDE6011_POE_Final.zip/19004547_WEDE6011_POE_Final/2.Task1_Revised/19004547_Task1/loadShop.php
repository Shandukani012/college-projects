<?php

session_start();
if(!isset($_SESSION['email'])){
    header("location:index.php");
}

if(isset($_POST['submit']))
{
    header("location:login.php");
    
    unset($_SESSION['email']);  
    session_destroy(); 
}

?>
<!DOCTYPE html>
<html>

<head>
    <title> store &amp; </title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />   
	
	
	<style>
		<!-- STYLING IMAGE TABLES -->
	h1 {
  text-shadow: 2px 2px red;
  
}
	table {
	border-collapse: collapse;
    font-family: Tahoma, Geneva, sans-serif;
}
table td {
	padding: 15px;
border:  solid transparent;
}
table thead td {
	background-color: #54585d;
	color: #ffffff;
	font-weight: bold;
	font-size: 13px;
	img {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 150px;
}

	
}
table tbody td {
	color: #636363;
	
}
table tbody tr {
	background-color: #f9fafb;
}
table tbody tr:nth-child(odd) {
	background-color: #ffffff;
}
img:hover{
-webkit-transform: scaleX(-1);
transform: scaleX(-1);	

	
	p {
	color: #ee82ee;
	font-size: 33px;
	padding: 10px;}	
}
button {
	float: right;
	background: #ff6347;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
</style>
</head>

<body>

<center>
              <h1  bgcolor="white"><marquee direction="left">Classic handbags we got your style!!! Enjoy shopping  </marquee></h1>
    <p><marquee direction="down" height="200" width="800" > <img src="bg2.gif" position "center"height="100" width="400"  /> </marquee> </p>

        <form method="post">
            <input  type="submit" name="submit" value="Logout" />
        </form>
    <br>
    <hr>
    <br>
<table border="0" cellspacing="1" cellpadding="5">
            <tr>
            <td><b>product</b></td>
            <td><b>Hand bags</b></td>
            <td><b>Price</b></td>
			<td><b>Buy</b></td>
        </tr>
<?php
// Include the database configuration file
include('dbConn.php');

// Get images from the database
$sql = "SELECT * FROM tblproducts";
$query = mysqli_query($conn,$sql);

if(mysqli_num_rows($query) > 0){
    while($row = mysqli_fetch_assoc($query)){
        $imageURL = $row["image"];
        $imageDesc = $row["pname"];
        $sellprice = $row["price"];
?>

    <tr>
    <td>
	<!--//display images in table form-->
    <p><?php echo $imageDesc; ?></p>
    </td>
    <td>
    <img src="<?php echo $imageURL; ?>" alt="" width ="30%" />
    </td> 
    <td>
    <p><?php echo "<b>R </b>".$sellprice; ?></p>
    </td>
	
	<td>
	<center>
    <button type="button" onclick='alert("<?php echo "R ".$sellprice; ?>")' >Add to Cart!!</button>
	<br><br>
	<input type="number" style="width:30px">
	</center>
    </td>
    </tr>
<?php }
}else{ ?>
    <p>add images</p>
<?php } ?>
</table>

</center>


</body>
</html>
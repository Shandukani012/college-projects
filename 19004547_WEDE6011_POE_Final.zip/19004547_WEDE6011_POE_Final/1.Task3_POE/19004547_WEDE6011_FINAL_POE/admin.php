 <?php
	
    include_once('dbConn.php');
    include_once('createTable.php');
	unset($_SESSION['email']); 
	
    $output = NULL;
    $email = $pass = "";

    if(isset($_POST['save']))
    {
		$email = $_POST['email'];
        $pass = $_POST['pass'];
        $hpass = md5($pass);
		$_SESSION['email'] = $email;
		
        $query = "SELECT * FROM tblcustomers WHERE email = '$email' AND password = '$hpass'";
        
        $result = mysqli_query($conn,$query);

        $row = mysqli_fetch_array($result);

		$_SESSION['cid'] = $row['cid'];
		
		if($email == "admin@admin.com" && $pass == "admin") {
	  
			  $_SESSION['emailx'] = $email;
			  $_SESSION['success'] = "You are now logged in";
			  header('location: admin/productsList.php');  
		}
        
		  
        if(empty($email))
        {
            $output = "Please eneter email";
        }
        else 
        { 
             
                $output = "Incorrect Username\Password";
            }
        
        }
    
    
    ?>
	
	
<!DOCTYPE html>
	<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
 <form method="post">
     	<h2>ADMIN</h2>
     	
     	
     	<label>User Name</label>
     	<input type="text" name="email" placeholder="email"><br>

     	<label>Password</label>
     	<input type="password" name="pass"  "<?php echo $email; ?>" placeholder="Password"><br>

     	<input type="submit" name="save" value="LOGIN"><br>
          <p> Click here to login As Customer <a href="login.php">Login</a></p> 
     </form>
</body>
		
		
			 <?php
    echo "<br>";
    echo $output;
    ?>
        
       
        </center>
    
			</center>
		
	</body>


	</html>
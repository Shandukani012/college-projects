<?php  

  include('..\dbConn.php');

  if (!isset($_SESSION['emailx'])) {
  	//$_SESSION['msg'] = "You must log in first";
  	header('location: ../admin.php');
  }
 
  if (isset($_GET['logout1'])) {
  	session_destroy();
  	//unset($_SESSION['email']);
  	header("location: ../login.php");
  } 

// initialize variables
	$pname = "";
	$price = "";
	$pid = 0;
	$imageURL = "<img src= > ";
	
	$update = false;

	if (isset($_POST['save'])) {
		$pname = $_POST['pname'];
		$price = $_POST['price'];
		$imageURL =$_POST['image'] ;
		$qnty = 20;
		
		mysqli_query($conn, "INSERT INTO tblproducts (pname, price, image, qnty) VALUES ('$pname','$price', '$imageURL',$qnty)"); 
		$_SESSION['message'] = "Product added!!!"; 
		header('location: productsList.php');	
	}
	
		if (isset($_GET['edit'])) {
		$pid = $_GET['edit'];
		$update = true;
		$record = mysqli_query($conn, "SELECT * FROM tblproducts WHERE pid=$pid");

		if (mysqli_num_rows($record) == 1 ) {
			$n = mysqli_fetch_array($record);
			$pname = $n['pname'];
			$price = $n['price'];
		    $imageURL= $n['image'];
		}
	}
	
	
	if (isset($_POST['update'])) {
		$pid = $_POST['pid'];
		$pname = $_POST['pname'];
		$price = $_POST['price'];
		$imageURL= $_POST['image'];
		
		
	mysqli_query($conn, "UPDATE tblproducts SET  pname='$pname', price = '$price' , image ='$imageURL' WHERE pid=$pid");
		$_SESSION['message'] = "Product updated!"; 
		header('location:productsList.php');
		
		
		
		
	}
	
		if (isset($_GET['del'])) {
		$id = $_GET['del'];
		mysqli_query($conn, "DELETE FROM tblproducts WHERE pid=$id");
		$_SESSION['message'] = "Product deleted!"; 
		header('location: productsList.php');
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Princess Purse Admin </title>
	
		<style>
		<!-- STYLING IMAGE TABLES -->
	
	header{
		
		
	  width: 608px;
  margin: 5px auto 0px;
  color: black;
  background: #6aadf1;
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 0px 0px 0px 0px;
  padding: 1px;	
		
		
	}
	
	h2 {
  	
	  width: 608px;
  margin: 5px auto 0px;
  color: blue;
  background: #6aadf1;
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 0px 0px 0px 0px;
  padding: 1px;	
  
}


p {
	
	  width: 608px;
  margin: 5px auto 0px;
  color: blue;
  background: #6aadf1;
  text-align: center;
  border: 1px solid #B0C4DE;
  border-bottom: none;
  border-radius: 0px 0px 0px 0px;
  padding: 1px;}
	h1 {
  text-shadow: 2px 2px red;
  
}
	table {
	border-collapse: collapse;
    font-family: Tahoma, Geneva, sans-serif;
}
table td {
	padding: 15px;
border:  solid transparent;

}
table thead td {
	background-color: #54585d;
	color: #ffffff;
	font-weight: bold;
	font-size: 13px;
border: none;

}

	img {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 150px;
}

	
}
table tbody td {
	color: #636363;
	
}
table tbody tr {
	background-color: #f9fafb;
}
table tbody tr:nth-child(odd) {
	background-color: #ffffff;
}
img:hover{
-webkit-transform: scaleX(-1);
transform: scaleX(-1);	

	
		
}
button {
	float: right;
	background: #ff6347;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
}
		</style>
</head>
<body>
<center>
<div>
  	<h2> Princess Purse Admin </h2>
  </div>

  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['emailx'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['emailx']; ?></strong></p>
    	<p>  <a href="productsList.php?logout1='1'" style="color:PaleVioletRed;">logout</a> </p>&nbsp;
    <?php endif ?>
</div>

 

<?php $results = mysqli_query($conn, "SELECT * FROM tblproducts"); ?>


	<h3> Product List </h3>
	
	<?php if (isset($_SESSION['message'])): ?>
	<div class="msg">
		<?php 
			echo $_SESSION['message']; 
			unset($_SESSION['message']);
		?>
	</div>
<?php endif ?>
<br>

	<table border="1" cellspacing="1" cellpadding="1">
		<thead>
			<tr>
				<th>Name</th>
				<th>Price</th>
				<th>Images</th>
				
				<th colspan="2">Action</th>
			</tr>
		</thead>
		
		<?php while ($row = mysqli_fetch_array($results)) { ?>
			<tr>
				<td><?php echo $row['pname']; ?></td>
				<td><?php echo "<b>R :</b>".$row['price']; ?></td>
				<td><?php echo '<img src="'.$row['image'].'" height = "100px" width ="100px" >' ?></td>
				<td>
					<button type="button"><a href="productsList.php?edit=<?php echo $row['pid']; ?>" >Edit</a></button>
				</td>
				<td>
					<button type="button"><a href="productsList.php?del=<?php echo $row['pid']; ?>">Delete</a></button>
				</td>
			</tr>
		<?php } ?>
	</table>
	<br>


	<hr width = "595">

	<h3> Add Product </h3>
	
<div>
	<form method="post" action="" >
	<input type="hidden" name="pid" value="<?php echo $pid; ?>">
		<table>
		<tr>
			<td>Name</td><td><input type="text" name="pname" value="<?php echo $pname; ?>"></td>
		</tr>
		<tr>
			<td>Price</td><td><input type="text" name="price" value="<?php echo $price; ?>"></td>
		</tr>
		<tr>
			<td>Image</td><td><input type="file" name="image" value="<?php echo $imageURL; ?>"></td>
		</tr>
		
		
		<tr><td></td>
			<td>
			<?php if ($update == true): ?>
				<button class="btn" type="submit" name="update" style="background: #008B8B" >update</button>
			<?php else: ?>
				<button class="btn" type="submit" name="save" >Save</button>
			<?php endif ?>
			</td>
			
			
		</tr>
		</table>
	</form>
</div>
<div></div>
</div>
  

      <p>&copy;Copyright - Vakorinte Media Associates</p>
  </div>

</center>
</body>
</html>
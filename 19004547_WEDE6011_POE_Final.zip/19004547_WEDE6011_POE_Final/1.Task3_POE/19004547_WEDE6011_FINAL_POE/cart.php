<?php
require 'dbConn.php';
require 'item.php';

if(!isset($_SESSION['email'])){
    header("location:login.php");
}

if(isset($_POST['submit']))
{
    header("location:login.php");
    
    unset($_SESSION['email']);  
    session_destroy(); 
}

if(isset($_POST['shop']))
{
    header("location:loadShop.php");
}

if (isset ( $_GET ['id'] ) && !isset($_POST['update'])) {

	$result = mysqli_query ( $conn, 'select * from tblproducts where pid=' . $_GET ['id'] );
	$product = mysqli_fetch_object ( $result );
	$item = new Item ();
	$item->id = $product->pid;
	$item->name = $product->pname;
	$item->price = $product->price;
	$item->quantity = 1;
	// Check product is existing in cart
	$index = - 1;
	if (isset ( $_SESSION ['cart'] )) {
		$cart = unserialize ( serialize ( $_SESSION ['cart'] ) );
		for($i = 0; $i < count ( $cart ); $i ++)
		if ($cart [$i]->id == $_GET ['id']) {
			$index = $i;
			break;
		}
	}
	if ($index == - 1)
	$_SESSION ['cart'] [] = $item;
	else {
		$cart [$index]->quantity ++;
		$_SESSION ['cart'] = $cart;
	}
}

// Delete product in cart
if (isset ( $_GET ['index'] ) && !isset($_POST['update'])) {
	$cart = unserialize ( serialize ( $_SESSION ['cart'] ) );
	unset ( $cart [$_GET ['index']] );
	$cart = array_values ( $cart );
	$_SESSION ['cart'] = $cart;
}

// Update quantity in cart
if(isset($_POST['update'])) {
	$arrQuantity = $_POST['quantity'];

	// Check validate quantity
	$valid = 1;
	for($i=0; $i<count($arrQuantity); $i++)
	if(!is_numeric($arrQuantity[$i]) || $arrQuantity[$i] < 1){
		$valid = 0;
		break;
	}
	if($valid==1){
		$cart = unserialize ( serialize ( $_SESSION ['cart'] ) );
		for($i = 0; $i < count ( $cart ); $i ++) {
			$cart[$i]->quantity = $arrQuantity[$i];
		}
		$_SESSION ['cart'] = $cart;
	}
	else
		$error = 'Quantity is InValid';
}

?>

<?php echo isset($error) ? $error : ''; ?>
<!DOCTYPE html>
<html>
<head><title>Princess Purses Cart </title>
<link href="styles.css" rel="stylesheet" type="text/css">
<head>
<body>
<style>
		<!-- STYLING cart TABLES -->
	h1 {
  text-shadow: 2px 2px red;
  
}
	table {
	border-collapse: collapse;
    font-family: Tahoma, Geneva, sans-serif;
}
table td {
	padding: 15px;
border:  solid transparent;
}
table thead td {
	background-color: pink;
	color: red;
	font-weight: bold;
	font-size: 13px;
	img {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 150px;
}

	
}
table tbody td {
	color: #636363;
	
}
table tbody tr {
	background-color: pink;
		background-color: #blue;
	color: #pink;
	font-weight: bold;
	font-size: 13px;
	img {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 150px;
}
table tbody tr:nth-child(odd) {
	background-color: #red;
}
img:hover{
-webkit-transform: scaleX(-1);
transform: scaleX(-1);	

	
	p {
	color: #ee82ee;
	font-size: 33px;
	padding: 10px;}	
}
button {
	float: right;
	background: #ff6347;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-right: 10px;
	border: none;
</style>
<center>

<p>You can add or remove items from you cart <b><?php echo $_SESSION['email']; ?></b></p>

        <form method="post">
            <input type="submit" name="shop" value="Continue Shopping" />

            <input type="submit" name="submit" value="Logout" />
        </form>
<br>
<hr>		
<br>
<form method="post">
	<table cellpadding="2" cellspacing="2" border="1">
		<tr>
			<th>Option</th>
			<th>Name</th>
			<th>Price</th>
			<th>Quantity <input type="image" src="image\save.png" width = "20px"> <input
				type="hidden" name="update">
			</th>
			<th>Sub Total</th>
		</tr>
		<?php
		$cart = unserialize ( serialize ( $_SESSION ['cart'] ) );
		$s = 0;
		$index = 0;
		for($i = 0; $i < count ( $cart ); $i ++) {
			$s += $cart [$i]->price * $cart [$i]->quantity;
			?>
		<tr>
			<td><a href="cart.php?index=<?php echo $index; ?>"
				onclick="return confirm('Are you sure?')">Remove
				</a></td>
			<td><?php echo $cart[$i]->name; ?></td>
			<td><?php echo "R :".$cart[$i]->price; ?></td>
			<td><center><input type="number" value="<?php echo $cart[$i]->quantity; ?>"
				style="width: 50px;" name="quantity[]"></center></td>
			<td><?php echo "R :".$cart[$i]->price * $cart[$i]->quantity; ?></td>
		</tr>
		<?php
		$index ++;
		}
		?>
		<tr>
			<td colspan="4" align="right"><b>Grand Total</b></td>
			<td align="left"><?php echo "<b>R :$s</b>"; ?></td>
		</tr>
	</table>
</form>
<br>
<a href="loadShop.php">Continue Shopping</a> | <a href="checkout.php">Checkout</a>
</center>
</body>
</html>
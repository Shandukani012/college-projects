<?php

session_start();
if(!isset($_SESSION['email'])){
    header("location:login.php");
}

if(isset($_POST['submit']))
{
    header("location:login.php");
    
    unset($_SESSION['email']);  
    session_destroy(); 
}

if(isset($_POST['shop']))
{
    header("location:loadShop.php");
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>Princess Purses</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />   
	<link href="styles.css" rel="stylesheet" type="text/css">
	
		<style>
	p {
	color: #ee82ee;
	font-size: 33px;
	padding: 10px;

}
	</style>
</head>

<body>

<center>
<h1  bgcolor="white"><marquee direction="left">Loged in successful !!!Press Start shopping now dont waste Time </marquee></h1>

        <form method="post">
            <input type="submit" name="shop" value="Start Shopping" />

            <input type="submit" name="submit" value="Logout" />
        </form>
 <p><marquee direction="down" height="200" width="800" > <img src="bg2.gif" position "center"height="100" width="400"  />Welocome to Princess Purses <b><?php echo $_SESSION['email']; ?></b> its all stars here! carry with confidence</marquee></p>

</center>


</body>
</html>
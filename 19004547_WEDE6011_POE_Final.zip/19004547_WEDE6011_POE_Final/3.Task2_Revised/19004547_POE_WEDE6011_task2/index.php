 <?php


    session_start();
    include_once('dbConn.php');
	include_once('loadMyShop.php');
	
?>

<!DOCTYPE html>
<html>

<head>
    <title>Princess Purses</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />   
	<link href="style.css" rel="stylesheet" type="text/css">
	
		<style>
	p {
	color: #ee82ee;
	font-size: 33px;
	padding: 10px;

}
	</style>
</head>

<body>

<center>
<h1  bgcolor="white"><marquee direction="left">Welocome to Princess Pursesall starts here! carry with confidence</marquee></p>
 </marquee></h1>

</center>


</body>
</html>
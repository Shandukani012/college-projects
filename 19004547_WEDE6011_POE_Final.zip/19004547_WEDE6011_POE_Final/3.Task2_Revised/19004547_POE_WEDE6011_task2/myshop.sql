
CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




CREATE TABLE IF NOT EXISTS `tbl_items` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `pname` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `Image` varchar(50) NOT NULL,
  `qnty` int(10) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `tbl_orderitems` (
  `oid` int(10) NOT NULL,
  `pid` int(10) NOT NULL,
  KEY `oid` (`oid`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `tbl_orders` (
  `oid` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL,
  `qnty` int(10) NOT NULL,
  PRIMARY KEY (`oid`),
  KEY `cid` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `tbl_orderitems`
  ADD CONSTRAINT `tbl_orderitems_ibfk_1` FOREIGN KEY (`oid`) REFERENCES `tbl_orders` (`oid`),
  ADD CONSTRAINT `tbl_orderitems_ibfk_2` FOREIGN KEY (`pid`) REFERENCES `tbl_items` (`pid`);


ALTER TABLE `tbl_orders`
  ADD CONSTRAINT `tbl_orders_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `tbl_customer` (`cid`);